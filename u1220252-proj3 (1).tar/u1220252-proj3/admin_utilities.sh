admin_passcode="passcode123"

while true
do
echo "Main menu"
echo "choose number"
echo "1-Login as admin"
echo "2-view system information"
echo "3-exit"
read option

case $option in
1)
echo "enter passcode"
read -s passcode
if test "$passcode" = "$admin_passcode" 
then
echo "admin utilities"
echo "choose number"
echo "1-memory usage"
echo "2-CPU usage"
echo "3-disk usage"
echo "4-who's there"
echo "5-show network information"
read number
case $number in
1)
memory_info=$(free -m | grep Mem)
total_mem=$(echo $memory_info | cut -d' ' -f2)
used_mem=$(echo $memory_info | cut -d' ' -f3)
mem_percentage=$((used_mem * 100 / total_mem))
echo "total memory:"
echo "$total_mem"
echo "used memory:"
echo "$used_mem"
echo "memory usage:"
echo "$mem_percentage"
;;
2)
cpu_info=$(top -bn1 | grep "Cpu(s)")
cpu_usage=$(echo $cpu_info | cut -d' ' -f2 | cut -d'.' -f1)
echo "CPU usage:"
echo "$cpu_usage"
;;
3)
disk_info=$(df -h / | grep '/')
disk_usage=$(echo $disk_info | tr -s ' ' | cut -d ' ' -f5)
echo "Disk usage"
echo "$disk_usage"
;;
4)
echo "sending email notification to admin"
echo "high system resource usage detected! action may be required" | mail -s "Resource usage alert" "$USER"
;;
5)
echo "user:"
who
;;
*)
echo "error"
;;
esac
else
echo "wrong passcode"
fi
;;
2)
echo "system information"
echo "Host name:"
echo "$HOSTNAME"
echo "operating system:"
echo "$(uname -s)"
echo "version:"
echo "$(uname -r)"
echo "CPU info"
lscpu | grep "Model name"
;;
3)
break
;;
*)
echo "error"
;;
esac
done
